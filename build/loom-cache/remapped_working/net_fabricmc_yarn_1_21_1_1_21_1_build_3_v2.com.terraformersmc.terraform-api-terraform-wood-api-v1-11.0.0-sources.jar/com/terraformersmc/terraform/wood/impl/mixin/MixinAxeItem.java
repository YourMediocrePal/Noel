package com.terraformersmc.terraform.wood.impl.mixin;

import com.terraformersmc.terraform.wood.api.block.BareSmallLogBlock;
import com.terraformersmc.terraform.wood.api.block.QuarterLogBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.block.BlockState;
import net.minecraft.item.AxeItem;

@Mixin(AxeItem.class)
public class MixinAxeItem {
	@Inject(method = "getStrippedState", at = @At("TAIL"), cancellable = true)
	private void terraform$getStrippedState(BlockState oldState, CallbackInfoReturnable<Optional<BlockState>> cir) {
		cir.getReturnValue().ifPresent(newState -> {
			class_2248 newBlock = newState.method_26204();
			// SmallLogBlock extends BareSmallLogBlock
			if (newBlock instanceof BareSmallLogBlock || newBlock instanceof QuarterLogBlock) {
				cir.setReturnValue(Optional.of(newBlock.method_34725(oldState)));
			}
		});
	}
}
